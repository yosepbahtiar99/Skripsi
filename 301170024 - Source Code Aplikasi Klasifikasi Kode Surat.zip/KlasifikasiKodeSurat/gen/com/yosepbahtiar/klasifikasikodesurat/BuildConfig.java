/** Automatically generated file. DO NOT MODIFY */
package com.yosepbahtiar.klasifikasikodesurat;

public final class BuildConfig {
	public final static boolean DEBUG = true;
}